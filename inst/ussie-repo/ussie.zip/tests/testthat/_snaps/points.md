# uss_points_per_game() works

    Using default value, 4, where country not available:
    ! Country not available: "tatooine".

---

    country and season must have same length:
    * country has length 1.
    * season has length 2.

