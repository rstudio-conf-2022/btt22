# formatting works

    Code
      print(result)
    Output
      <ussie_result[3]>
      [1] L 1-2 D 2-2 W 3-2

