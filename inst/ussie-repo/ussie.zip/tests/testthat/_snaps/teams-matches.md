# uss_make_teams_matches works

    Code
      dplyr::glimpse(italy)
    Output
      Rows: 50,808
      Columns: 9
      $ country       <chr> "Italy", "Italy", "Italy", "Italy", "Italy", "Italy", "I~
      $ tier          <fct> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,~
      $ season        <int> 1929, 1929, 1929, 1929, 1929, 1929, 1929, 1929, 1929, 19~
      $ team          <chr> "AC Milan", "AC Milan", "AC Milan", "AC Milan", "AC Mila~
      $ date          <date> 1929-10-06, 1929-10-13, 1929-10-20, 1929-10-27, 1929-11~
      $ at_home       <lgl> TRUE, TRUE, FALSE, TRUE, FALSE, TRUE, FALSE, TRUE, FALSE~
      $ opponent      <chr> "Brescia Calcio", "Modena FC", "SSC Napoli", "AS Roma", ~
      $ goals_for     <int> 4, 1, 1, 3, 1, 1, 1, 2, 1, 5, 0, 1, 3, 1, 2, 1, 2, 1, 1,~
      $ goals_against <int> 1, 0, 2, 1, 1, 2, 4, 1, 3, 2, 1, 1, 2, 0, 1, 2, 2, 4, 1,~

