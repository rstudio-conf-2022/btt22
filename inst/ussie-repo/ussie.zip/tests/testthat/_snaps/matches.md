# uss_make_matches works

    Code
      dplyr::glimpse(italy)
    Output
      Rows: 25,404
      Columns: 8
      $ country       <chr> "Italy", "Italy", "Italy", "Italy", "Italy", "Italy", "I~
      $ tier          <fct> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,~
      $ season        <int> 1934, 1934, 1934, 1934, 1934, 1934, 1934, 1934, 1934, 19~
      $ date          <date> 1934-09-30, 1934-09-30, 1934-09-30, 1934-09-30, 1934-09~
      $ home          <chr> "Lazio Roma", "Torino FC", "Sampierdarenese", "SSC Napol~
      $ visitor       <chr> "US Livorno", "Unione Triestina", "Bologna FC", "US Ales~
      $ goals_home    <int> 6, 3, 2, 0, 4, 0, 3, 1, 1, 1, 2, 4, 2, 2, 3, 2, 2, 2, 0,~
      $ goals_visitor <int> 1, 1, 1, 1, 1, 2, 0, 2, 1, 1, 1, 0, 2, 1, 1, 0, 1, 1, 1,~

