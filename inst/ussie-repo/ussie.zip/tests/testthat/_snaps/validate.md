# validate_data_frame works

    Must supply a data frame
    x You have supplied a <numeric>.

# validate_cols works

    Data frame needs column: `foo`
    i Has columns: `mpg`, `cyl`, `disp`, `hp`, `drat`, `wt`, `qsec`, `vs`, `am`, `gear`, and `carb`
    x Missing column: `foo`

