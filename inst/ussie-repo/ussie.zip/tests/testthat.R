library(testthat)
library(ussie)

test_check("ussie")
