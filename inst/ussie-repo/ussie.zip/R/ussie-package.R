#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import vctrs
#' @importFrom rlang :=
#' @importFrom rlang .data
#' @importFrom rlang .env
#' @importFrom tibble tibble
## usethis namespace: end
NULL

